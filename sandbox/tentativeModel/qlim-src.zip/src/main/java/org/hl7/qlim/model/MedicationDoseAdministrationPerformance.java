
package org.hl7.qlim.model;

import org.hl7.qlim.action.MedicationTreatment;
import org.hl7.qlim.action.Performance;

public interface MedicationDoseAdministrationPerformance
    extends MedicationTreatment, Performance
{

    	// mixin


}
