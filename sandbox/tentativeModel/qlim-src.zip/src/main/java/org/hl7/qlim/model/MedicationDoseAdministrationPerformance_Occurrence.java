
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;


/**
 * Aspect would REQUIRE code for Administration of Dose. 
 * 
 * The dispense attribute/association in MedicationTreatment will be expected to be null.
 * 
 * The dosage attribute/association in MedicationTreatment will be of type DosageAdministration
 * 
 */
public class MedicationDoseAdministrationPerformance_Occurrence
    extends StatementOfOccurrence
    implements MedicationDoseAdministrationPerformance
{

    

}
