package org.hl7.qlim.Entity;

/**
A way to provide food through a tube placed in the nose, mouth, the stomach, or the small intestine. 
*/
public class EnteralFormula
	extends NutritionItem {
// Quantity caloricDensity
// NutritionProduct product
// DosageInstruction administration
// EntityCharacteristic characteristic
}
