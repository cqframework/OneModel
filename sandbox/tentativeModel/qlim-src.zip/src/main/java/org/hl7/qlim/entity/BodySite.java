
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * A location on a person's body.  E.g., left breast, heart.
 * 
 */
public class BodySite
    extends Entity
{

    private CodeDt anatomicalLocation;
    private CodeDt directionality;
    private CodeDt laterality;

    public CodeDt getAnatomicalLocation() {
        return anatomicalLocation;
    }

    public void setAnatomicalLocation(CodeDt value) {
        anatomicalLocation = value;
    }

    public CodeDt getDirectionality() {
        return directionality;
    }

    public void setDirectionality(CodeDt value) {
        directionality = value;
    }

    public CodeDt getLaterality() {
        return laterality;
    }

    public void setLaterality(CodeDt value) {
        laterality = value;
    }
    

}
