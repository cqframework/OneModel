
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfUnknownOccurrence;

public class EncounterProposalAgainst_UnknownOccurrence
    extends StatementOfUnknownOccurrence
    implements EncounterProposalAgainst
{

    

}
