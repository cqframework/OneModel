
package org.hl7.qlim.action;


public class DosageAdministration
    extends Dosage
{

    

}
