
package org.hl7.qlim.phenomenon;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.dstu.composite.PeriodDt;
import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * A description of an undesirable physiologic or other reaction to an external stimulus.
 * 
 */
public class AllergyIntolerance
    implements Phenomenon
{

    private CodeDt criticality;
    private PeriodDt effectiveTime;
    private List<CodeDt> reaction;
    private CodeDt sensitivityType;
    private CodeDt stimulus;

    public CodeDt getCriticality() {
        return criticality;
    }

    public void setCriticality(CodeDt value) {
        criticality = value;
    }

    public PeriodDt getEffectiveTime() {
        return effectiveTime;
    }

    public void setEffectiveTime(PeriodDt value) {
        effectiveTime = value;
    }

    public List<CodeDt> getReaction() {
        if (reaction == null) {
            reaction = new ArrayList<CodeDt>();
        }
        return reaction;
    }

    public void setReaction(List<CodeDt> value) {
        reaction = value;
    }

    public CodeDt getSensitivityType() {
        return sensitivityType;
    }

    public void setSensitivityType(CodeDt value) {
        sensitivityType = value;
    }

    public CodeDt getStimulus() {
        return stimulus;
    }

    public void setStimulus(CodeDt value) {
        stimulus = value;
    }
    

}
