package org.hl7.qlim.Phenomenon;

import org.hl7.qlim.Core.StatementTopic;

/**
The outcome of medical investigations or diagnostics. "<i>Clinical findings</i>" are the observations made during the history and physical.
*/
public interface Phenomenon extends StatementTopic {
// mixin
// Period observedAtTime
}
