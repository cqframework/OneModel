
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * This element identifies an instance of a manufactured thing that is used in the provision of healthcare without being substantially changed through that activity. The device may be a machine, an insert, a computer, an application, etc. This includes durable (reusable) medical equipment as well as disposable equipment used for diagnostic, treatment, and research for healthcare and public health.
 * 
 */
public class Device
    extends ManufacturedProduct
{

    private Location location;
    private String model;
    private Organization owner;
    private Patient patient;
    private CodeDt type;
    private String version;

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location value) {
        location = value;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String value) {
        model = value;
    }

    public Organization getOwner() {
        return owner;
    }

    public void setOwner(Organization value) {
        owner = value;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient value) {
        patient = value;
    }

    public CodeDt getType() {
        return type;
    }

    public void setType(CodeDt value) {
        type = value;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String value) {
        version = value;
    }
    
	// TelecomAddress url

}
