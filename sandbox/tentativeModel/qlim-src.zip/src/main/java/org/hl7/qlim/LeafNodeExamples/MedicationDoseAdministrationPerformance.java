package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Action.Performance;
import org.hl7.qlim.Action.MedicationTreatment;

public interface MedicationDoseAdministrationPerformance extends Performance, MedicationTreatment {
// mixin
// Code aspectPerformed
// Participant participant
// TimePeriod performedAtTime
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
// Medication medication
// Dispense dispense
// Dosage dosage
// MedicationParameters details
}
