package org.hl7.qlim.Phenomenon;

/**
A description of an undesirable physiologic or other reaction to an external stimulus.
*/
public class AllergyIntolerance implements Phenomenon {
// Code criticality
// TimePeriod effectiveTime
// Code reaction
// Code sensitivityType
// Code stimulus
// Period observedAtTime
}
