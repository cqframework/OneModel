package org.hl7.qlim.Entity;

/**
A sample of tissue, blood, urine, water, air, etc., taken for the purposes of diagnostic examination or evaluation.
*/
public class Specimen
	extends Entity {
// Code collectionMethod
// BodySite collectionSite
// Patient subject
// Code type
// EntityCharacteristic characteristic
}
