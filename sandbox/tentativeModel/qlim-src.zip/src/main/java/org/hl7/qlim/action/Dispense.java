
package org.hl7.qlim.action;

import ca.uhn.fhir.model.dstu.composite.PeriodDt;


/**
 * Details of the dispensation such as the days supply and quantity of medication (to be) dispensed.
 * 
 */
public class Dispense {

    private PeriodDt dispenseTime;

    public PeriodDt getDispenseTime() {
        return dispenseTime;
    }

    public void setDispenseTime(PeriodDt value) {
        dispenseTime = value;
    }
    
	// Quantity amount
	// Quantity numberOfRepeatsAllowed

}
