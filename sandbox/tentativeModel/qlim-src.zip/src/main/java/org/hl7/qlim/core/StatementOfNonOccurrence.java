
package org.hl7.qlim.core;


public class StatementOfNonOccurrence
    extends ClinicalStatement
{

    

}
