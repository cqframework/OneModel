
package org.hl7.qlim.model;

import org.hl7.qlim.action.Performance;
import org.hl7.qlim.action.Procedure;

public interface ProcedurePerformance
    extends Performance, Procedure
{

    	// mixin


}
