
package org.hl7.qlim.action;



/**
 * Parameters for specific types of medications that can be administered.
 * 
 */
public class MedicationParameters {

    

}
