
package org.hl7.qlim.action;



/**
 * The proposal may be a recommendation from a clinical decision support system or advice from a consultation.
 * 
 */
public interface Proposal
    extends Action
{

    	// mixin

	// TimePeriod expectedPerformanceTime
	// TimePoint proposedAtTime
	// Code urgency

}
