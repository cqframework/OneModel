package org.hl7.qlim.Entity;

/**
Details about the vaccine product administered to the patient
*/
public class Vaccine
	extends ManufacturedProduct {
// Code vaccineType
// TimePoint expiry
// Text lotNumber
// Text manufacturerName
// EntityCharacteristic characteristic
}
