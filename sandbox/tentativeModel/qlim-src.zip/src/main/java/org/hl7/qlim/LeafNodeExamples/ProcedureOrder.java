package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Action.Order;
import org.hl7.qlim.Action.Procedure;

public interface ProcedureOrder extends Order, Procedure {
// mixin
// TimePeriod expectedPerformanceTime
// TimePoint orderedAtTime
// Code originationMode
// Code urgency
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
}
