package org.hl7.qlim.Phenomenon;

/**
Assertions and measurements made about a patient, device or other subject.

ObservationResults are a central element in healthcare, used to support diagnosis, monitor progress, determine baselines and patterns and even capture demographic characteristics. Fundamentally, observations are name/value pair assertions. Simple observation values, such a body temperature, are specified in the value attribute. Richer values, e.g., result panels, aggregate observations from diagnostic imaging, and microbiology sensitivity results,  are specified in the detailedResult attribute., 

This data type does not support the storage of the image or signal sequences such as electrocardiogram data.  However, the observations and interpretation made from the images and signals can be represented here.
*/
public class ObservationResult implements Phenomenon {
// BodySite bodySite
// Code interpretation
// Code method
// Code name
// Code reliability
// Code status
// Code validationMethod
// Value value
// ResultDetail detailedResult
// Period observedAtTime
}
