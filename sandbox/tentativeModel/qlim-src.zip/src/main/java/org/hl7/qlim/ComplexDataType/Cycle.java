package org.hl7.qlim.ComplexDataType;

/**
Represents a predictable periodic interval where events may occur at specific points within this interval. Examples may include:

1. An event that may occur TID.
2. An event that may occur TID but at specific times such as 8am, noon, and 3pm.
3. An event that may occur three times a day but the interval is not important.
4. An event that may occur three times a day where the interval between events must be 8hrs (Q8H).

Note that cycles may be nested. For instance, 
A chemotherapy regimen where a substance is administered TID on day 1,5,10 of a 10-day cycle.
*/
public class Cycle {
// Quantity cycleLagTime
// Quantity cycleLeadTime
// Quantity cycleLength
// Code cycleTiming
// TimePeriod endsOn
// Quantity totalCycleCount
}
