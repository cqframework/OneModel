package org.hl7.qlim.Action;

public class Activity {
// TimePeriod performedAtTime
// Code task
}
