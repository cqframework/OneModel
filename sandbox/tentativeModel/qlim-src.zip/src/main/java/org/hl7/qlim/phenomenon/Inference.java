
package org.hl7.qlim.phenomenon;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;
import org.hl7.qlim.core.ClinicalStatement;


/**
 * An inference made, about the patient's health, from other statements.
 * 
 */
public class Inference {

    private CodeDt inferenceMethod;
    private List<ClinicalStatement> inferredFrom;

    public CodeDt getInferenceMethod() {
        return inferenceMethod;
    }

    public void setInferenceMethod(CodeDt value) {
        inferenceMethod = value;
    }

    public List<ClinicalStatement> getInferredFrom() {
        if (inferredFrom == null) {
            inferredFrom = new ArrayList<ClinicalStatement>();
        }
        return inferredFrom;
    }

    public void setInferredFrom(List<ClinicalStatement> value) {
        inferredFrom = value;
    }
    

}
