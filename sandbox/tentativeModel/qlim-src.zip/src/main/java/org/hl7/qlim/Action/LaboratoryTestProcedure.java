package org.hl7.qlim.Action;

/**
Parameters for a procedure to test a specimen from a patient.
*/
public class LaboratoryTestProcedure implements Procedure {
// Code collectionMethod
// Code specialHandling
// Specimen specimenSource
// Code suspectedPathogen
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
}
