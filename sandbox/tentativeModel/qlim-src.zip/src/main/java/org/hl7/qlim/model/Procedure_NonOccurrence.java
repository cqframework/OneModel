
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfNonOccurrence;

public class Procedure_NonOccurrence
    extends StatementOfNonOccurrence
    implements ProcedurePerformance
{

    

}
