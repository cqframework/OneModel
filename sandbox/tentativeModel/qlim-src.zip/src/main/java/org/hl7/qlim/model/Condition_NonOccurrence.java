
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfNonOccurrence;
import org.hl7.qlim.phenomenon.Condition;

public class Condition_NonOccurrence
    extends StatementOfNonOccurrence
    implements Condition
{

    

}
