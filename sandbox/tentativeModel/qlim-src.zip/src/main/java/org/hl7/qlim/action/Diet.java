
package org.hl7.qlim.action;

import java.util.ArrayList;
import java.util.List;
import org.hl7.qlim.entity.NutritionItem;


/**
 * Description of diet/nutrition to be administered to a patient.
 * 
 */
public class Diet
    implements ActionModality
{

    private String foodModifier;
    private List<NutritionItem> nutritionItem;

    public String getFoodModifier() {
        return foodModifier;
    }

    public void setFoodModifier(String value) {
        foodModifier = value;
    }

    public List<NutritionItem> getNutritionItem() {
        if (nutritionItem == null) {
            nutritionItem = new ArrayList<NutritionItem>();
        }
        return nutritionItem;
    }

    public void setNutritionItem(List<NutritionItem> value) {
        nutritionItem = value;
    }
    

}
