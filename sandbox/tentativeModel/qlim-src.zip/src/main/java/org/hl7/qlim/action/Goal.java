
package org.hl7.qlim.action;

import ca.uhn.fhir.model.dstu.composite.PeriodDt;
import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * A defined target or measure to be achieved in the process of patient care; an expected outcome. A typical goal is expressed as a change in status expected at a defined future time.
 * 
 */
public class Goal
    implements ActionModality
{

    private PeriodDt goalAchievementTargetTime;
    private CodeDt goalFocus;
    private PeriodDt goalPursuitEffectiveTime;

    public PeriodDt getGoalAchievementTargetTime() {
        return goalAchievementTargetTime;
    }

    public void setGoalAchievementTargetTime(PeriodDt value) {
        goalAchievementTargetTime = value;
    }

    public CodeDt getGoalFocus() {
        return goalFocus;
    }

    public void setGoalFocus(CodeDt value) {
        goalFocus = value;
    }

    public PeriodDt getGoalPursuitEffectiveTime() {
        return goalPursuitEffectiveTime;
    }

    public void setGoalPursuitEffectiveTime(PeriodDt value) {
        goalPursuitEffectiveTime = value;
    }
    
	// Value goalValue

}
