
package org.hl7.qlim.entity;

import org.hl7.qlim.complexDataType.Schedule;


/**
 * A preparation intended to supplement the diet and provide calories or nutrients, such as vitamins, minerals, fiber, fatty acids, carbohydrates, or amino acids, that may be missing or may not be consumed in sufficient quantity in a person's diet. Such products may be ordered in addition to the diet (either general or therapeutic) to enhance a person�s intake. Supplemental food products provide some but not all of a patient�s nutritional needs. 
 * 
 * 
 */
public class NutritionalSupplement
    extends NutritionItem
{

    private Schedule frequency;
    private NutritionProduct product;

    public Schedule getFrequency() {
        return frequency;
    }

    public void setFrequency(Schedule value) {
        frequency = value;
    }

    public NutritionProduct getProduct() {
        return product;
    }

    public void setProduct(NutritionProduct value) {
        product = value;
    }
    
	// IntervalOfQuantity quantity

}
