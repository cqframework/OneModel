package org.hl7.qlim.Entity;

/**
This element identifies an instance of a manufactured thing that is used in the provision of healthcare without being substantially changed through that activity. The device may be a machine, an insert, a computer, an application, etc. This includes durable (reusable) medical equipment as well as disposable equipment used for diagnostic, treatment, and research for healthcare and public health.
*/
public class Device
	extends ManufacturedProduct {
// Location location
// Text model
// Organization owner
// Patient patient
// Code type
// TelecomAddress url
// Text version
// TimePoint expiry
// Text lotNumber
// Text manufacturerName
// EntityCharacteristic characteristic
}
