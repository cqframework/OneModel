package org.hl7.qlim.Action;

public interface ProposalAgainst extends Action {
// mixin
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
}
