package org.hl7.qlim.Action;

/**
Description of the participation of a patient in a recognized program of care such as a care plan, a chemotherapy protocol, or a clinical trial.
*/
public class CareProgram implements ActionModality {
// Goal goals
// Code participationStatus
// Code programType
}
