
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * A formally or informally recognized grouping of people or organizations formed for the purpose of achieving some form of collective action. Includes companies, institutions, corporations, departments, community groups, healthcare practice groups, etc.
 * 
 */
public class Organization
    extends Entity
{

    private String name;
    private CodeDt type;

    public String getName() {
        return name;
    }

    public void setName(String value) {
        name = value;
    }

    public CodeDt getType() {
        return type;
    }

    public void setType(CodeDt value) {
        type = value;
    }
    
	// Address address
	// TelecomAddress telecom

}
