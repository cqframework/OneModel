package org.hl7.qlim.Entity;

/**
A preparation intended to supplement the diet and provide calories or nutrients, such as vitamins, minerals, fiber, fatty acids, carbohydrates, or amino acids, that may be missing or may not be consumed in sufficient quantity in a person's diet. Such products may be ordered in addition to the diet (either general or therapeutic) to enhance a person�s intake. Supplemental food products provide some but not all of a patient�s nutritional needs. 

*/
public class NutritionalSupplement
	extends NutritionItem {
// Schedule frequency
// NutritionProduct product
// IntervalOfQuantity quantity
// EntityCharacteristic characteristic
}
