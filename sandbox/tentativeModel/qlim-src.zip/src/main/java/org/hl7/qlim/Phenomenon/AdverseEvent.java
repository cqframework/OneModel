package org.hl7.qlim.Phenomenon;

public class AdverseEvent implements Phenomenon {
// Code agent
// BodySite bodySite
// Code category
// Condition conditionDetail
// TimePeriod effectiveTime
// CodeableConcept name
// StatementOfOccurrence precedingExposure
// Code status
// Period observedAtTime
}
