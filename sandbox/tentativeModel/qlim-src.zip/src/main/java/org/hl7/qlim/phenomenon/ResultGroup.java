
package org.hl7.qlim.phenomenon;

import java.util.ArrayList;
import java.util.List;


/**
 * A group of related result values such as a laboratory result panel.  e.g., complete blood count, blood pressure
 * 
 */
public class ResultGroup
    extends ResultDetail
{

    private List<ObservationResult> component;

    public List<ObservationResult> getComponent() {
        if (component == null) {
            component = new ArrayList<ObservationResult>();
        }
        return component;
    }

    public void setComponent(List<ObservationResult> value) {
        component = value;
    }
    

}
