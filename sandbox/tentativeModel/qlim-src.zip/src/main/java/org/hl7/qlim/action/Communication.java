
package org.hl7.qlim.action;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;
import org.hl7.qlim.core.ClinicalStatement;


/**
 * A communication is a message sent between a sender and a recipient for a purpose and about a topic. 
 * 
 */
public class Communication
    implements ActionModality
{

    private CodeDt medium;
    private String message;
    private org.hl7.qlim.entity.Entity recipient;
    private org.hl7.qlim.entity.Entity sender;
    private List<ClinicalStatement> topic;

    public CodeDt getMedium() {
        return medium;
    }

    public void setMedium(CodeDt value) {
        medium = value;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String value) {
        message = value;
    }

    public org.hl7.qlim.entity.Entity getRecipient() {
        return recipient;
    }

    public void setRecipient(org.hl7.qlim.entity.Entity value) {
        recipient = value;
    }

    public org.hl7.qlim.entity.Entity getSender() {
        return sender;
    }

    public void setSender(org.hl7.qlim.entity.Entity value) {
        sender = value;
    }

    public List<ClinicalStatement> getTopic() {
        if (topic == null) {
            topic = new ArrayList<ClinicalStatement>();
        }
        return topic;
    }

    public void setTopic(List<ClinicalStatement> value) {
        topic = value;
    }
    

}
