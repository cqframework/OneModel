
package org.hl7.qlim.entity;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * A manufactured item that is administered for a patient's nutrition
 * 
 */
public class NutritionProduct
    extends ManufacturedProduct
{

    private List<CodeDt> attribute;
    private CodeDt type;

    public List<CodeDt> getAttribute() {
        if (attribute == null) {
            attribute = new ArrayList<CodeDt>();
        }
        return attribute;
    }

    public void setAttribute(List<CodeDt> value) {
        attribute = value;
    }

    public CodeDt getType() {
        return type;
    }

    public void setType(CodeDt value) {
        type = value;
    }
    

}
