package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Action.Procedure;
import org.hl7.qlim.Action.ProposalAgainst;

public interface ProcedureProposalAgainst extends Procedure, ProposalAgainst {
// mixin
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
}
