
package org.hl7.qlim.phenomenon;

import org.hl7.qlim.entity.Medication;


/**
 * Describes a contraindication to a healthcare related action, e.g., medication intake, procedure.
 * 
 * A contraindication is a specific situation in which a drug, procedure, or surgery should not be used because it may be harmful to the patient.
 * 
 */
public class Contraindication
    implements Phenomenon
{

    private Medication contraindicatedMedication;
    private Inference inference;

    public Medication getContraindicatedMedication() {
        return contraindicatedMedication;
    }

    public void setContraindicatedMedication(Medication value) {
        contraindicatedMedication = value;
    }

    public Inference getInference() {
        return inference;
    }

    public void setInference(Inference value) {
        inference = value;
    }
    

}
