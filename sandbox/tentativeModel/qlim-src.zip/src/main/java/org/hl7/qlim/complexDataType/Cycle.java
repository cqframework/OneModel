
package org.hl7.qlim.complexDataType;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.dstu.composite.PeriodDt;
import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Represents a predictable periodic interval where events may occur at specific points within this interval. Examples may include:
 * 
 *  1. An event that may occur TID.
 *  2. An event that may occur TID but at specific times such as 8am, noon, and 3pm.
 *  3. An event that may occur three times a day but the interval is not important.
 *  4. An event that may occur three times a day where the interval between events must be 8hrs (Q8H).
 * 
 * Note that cycles may be nested. For instance, 
 * A chemotherapy regimen where a substance is administered TID on day 1,5,10 of a 10-day cycle.
 * 
 */
public class Cycle {

    private List<CodeDt> cycleTiming;
    private PeriodDt endsOn;

    public List<CodeDt> getCycleTiming() {
        if (cycleTiming == null) {
            cycleTiming = new ArrayList<CodeDt>();
        }
        return cycleTiming;
    }

    public void setCycleTiming(List<CodeDt> value) {
        cycleTiming = value;
    }

    public PeriodDt getEndsOn() {
        return endsOn;
    }

    public void setEndsOn(PeriodDt value) {
        endsOn = value;
    }
    
	// Quantity cycleLagTime
	// Quantity cycleLeadTime
	// Quantity cycleLength
	// Quantity totalCycleCount

}
