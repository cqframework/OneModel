
package org.hl7.qlim.entity;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;
import org.hl7.qlim.complexDataType.Schedule;


/**
 * Concept generally representing food and/or a nutritional supplement prepared from food ingredients that is self-administered by a patient and consumed orally. 
 * 
 * 
 * A patient can have only one effective oral diet at a time.
 * 
 */
public class OralDiet
    extends NutritionItem
{

    private List<CodeDt> dietType;
    private CodeDt foodType;
    private Schedule frequency;
    private List<NutrientModification> nutrient;
    private List<TextureModification> texture;

    public List<CodeDt> getDietType() {
        if (dietType == null) {
            dietType = new ArrayList<CodeDt>();
        }
        return dietType;
    }

    public void setDietType(List<CodeDt> value) {
        dietType = value;
    }

    public CodeDt getFoodType() {
        return foodType;
    }

    public void setFoodType(CodeDt value) {
        foodType = value;
    }

    public Schedule getFrequency() {
        return frequency;
    }

    public void setFrequency(Schedule value) {
        frequency = value;
    }

    public List<NutrientModification> getNutrient() {
        if (nutrient == null) {
            nutrient = new ArrayList<NutrientModification>();
        }
        return nutrient;
    }

    public void setNutrient(List<NutrientModification> value) {
        nutrient = value;
    }

    public List<TextureModification> getTexture() {
        if (texture == null) {
            texture = new ArrayList<TextureModification>();
        }
        return texture;
    }

    public void setTexture(List<TextureModification> value) {
        texture = value;
    }
    

}
