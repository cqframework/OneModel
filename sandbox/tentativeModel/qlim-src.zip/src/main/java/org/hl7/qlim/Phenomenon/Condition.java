package org.hl7.qlim.Phenomenon;

/**
Use to record detailed information about conditions, problems or diagnoses recognized by a clinician. There are many uses including: recording a Diagnosis during an Encounter; populating a problem List or a Summary Statement, such as a Discharge Summary.
*/
public interface Condition extends Phenomenon {
// mixin
// BodySite bodySite
// Code category
// TimePeriod effectiveTime
// code encounterRole
// Code name
// Code status
// ConditionDetail conditionDetail
// Period observedAtTime
}
