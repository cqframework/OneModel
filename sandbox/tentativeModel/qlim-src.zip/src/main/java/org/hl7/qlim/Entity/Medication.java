package org.hl7.qlim.Entity;

/**
Primarily used for identification and definition of <code>Medication</code>, but also covers ingredients and packaging.
*/
public class Medication
	extends ManufacturedProduct {
// Code code
// Code form
// YesNo isBrand
// MedicationIngredient ingredient
// TimePoint expiry
// Text lotNumber
// Text manufacturerName
// EntityCharacteristic characteristic
}
