
package org.hl7.qlim.phenomenon;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Sensitivity of an organism to a specified antimicrobial agent
 * 
 */
public class OrganismSensitivity {

    private CodeDt organism;
    private CodeDt sensitivity;

    public CodeDt getOrganism() {
        return organism;
    }

    public void setOrganism(CodeDt value) {
        organism = value;
    }

    public CodeDt getSensitivity() {
        return sensitivity;
    }

    public void setSensitivity(CodeDt value) {
        sensitivity = value;
    }
    
	// Substance antiMicrobialAgent

}
