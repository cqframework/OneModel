
package org.hl7.qlim.action;



/**
 * Parameters for Patient Controlled Analgesia administration. For instance, morphine PCA, 5 mg loading dose, followed by 10 mg/hr basal rate, 1 mg demand dose, lockout interval 10 min.
 * 
 */
public class PatientControlledAnalgesia
    extends MedicationParameters
{

    
	// IntervalOfQuantity lockoutInterval

}
