package org.hl7.qlim.Phenomenon;

/**
Further detail about the condition, for example, intensity of pain.
*/
public class ConditionDetail {
// Code property
// Value value
}
