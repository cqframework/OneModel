package org.hl7.qlim.Action;

public abstract class Dosage {
// Schedule administrationSchedule
// BodySite administrationSite
// Code approachBodySite
// Code deliveryRoute
// Quantity doseQuantity
// Code doseType
// Quantity infuseOver
// Code method
// Quantity rate
}
