
package org.hl7.qlim.action;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;
import org.hl7.qlim.entity.Specimen;


/**
 * Parameters for a procedure to test a specimen from a patient.
 * 
 */
public class LaboratoryTestProcedure
    implements Procedure
{

    private CodeDt collectionMethod;
    private List<CodeDt> specialHandling;
    private Specimen specimenSource;
    private List<CodeDt> suspectedPathogen;

    public CodeDt getCollectionMethod() {
        return collectionMethod;
    }

    public void setCollectionMethod(CodeDt value) {
        collectionMethod = value;
    }

    public List<CodeDt> getSpecialHandling() {
        if (specialHandling == null) {
            specialHandling = new ArrayList<CodeDt>();
        }
        return specialHandling;
    }

    public void setSpecialHandling(List<CodeDt> value) {
        specialHandling = value;
    }

    public Specimen getSpecimenSource() {
        return specimenSource;
    }

    public void setSpecimenSource(Specimen value) {
        specimenSource = value;
    }

    public List<CodeDt> getSuspectedPathogen() {
        if (suspectedPathogen == null) {
            suspectedPathogen = new ArrayList<CodeDt>();
        }
        return suspectedPathogen;
    }

    public void setSuspectedPathogen(List<CodeDt> value) {
        suspectedPathogen = value;
    }
    

}
