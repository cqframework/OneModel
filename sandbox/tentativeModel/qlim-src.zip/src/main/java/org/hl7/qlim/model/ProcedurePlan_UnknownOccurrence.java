
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfUnknownOccurrence;

public class ProcedurePlan_UnknownOccurrence
    extends StatementOfUnknownOccurrence
    implements ProcedurePlan
{

    

}
