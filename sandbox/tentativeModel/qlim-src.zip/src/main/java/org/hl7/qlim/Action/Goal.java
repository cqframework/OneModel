package org.hl7.qlim.Action;

/**
A defined target or measure to be achieved in the process of patient care; an expected outcome. A typical goal is expressed as a change in status expected at a defined future time.
*/
public class Goal implements ActionModality {
// TimePeriod goalAchievementTargetTime
// Code goalFocus
// TimePeriod goalPursuitEffectiveTime
// Value goalValue
}
