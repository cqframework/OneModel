
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;

public class EncounterPlan_Occurrence
    extends StatementOfOccurrence
    implements EncounterPlan
{

    

}
