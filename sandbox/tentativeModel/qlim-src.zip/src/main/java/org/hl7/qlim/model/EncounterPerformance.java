
package org.hl7.qlim.model;

import org.hl7.qlim.action.Encounter;
import org.hl7.qlim.action.Performance;

public interface EncounterPerformance
    extends Encounter, Performance
{

    	// mixin


}
