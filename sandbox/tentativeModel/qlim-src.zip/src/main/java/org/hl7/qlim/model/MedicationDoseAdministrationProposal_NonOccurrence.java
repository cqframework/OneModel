
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfNonOccurrence;

public class MedicationDoseAdministrationProposal_NonOccurrence
    extends StatementOfNonOccurrence
    implements MedicationDoseAdministrationProposal
{

    

}
