package org.hl7.qlim.Action;

/**
An order is an instruction by a healthcare provider to another healthcare provider to perform some action.
*/
public interface Order extends Action {
// mixin
// TimePeriod expectedPerformanceTime
// TimePoint orderedAtTime
// Code originationMode
// Code urgency
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
}
