package org.hl7.qlim.Core;

public class StatementOfNonOccurrence
	extends ClinicalStatement {
// Text additionalText
// Encounter encounter
// ClinicalStatement predecessorStatement
// Code semanticType
// Person statementAuthor
// TimePoint statementDateTime
// Entity statementSource
// Patient subject
// ClinicalStatement successorStatement
// StatementTopic topic
}
