
package org.hl7.qlim.model;

import org.hl7.qlim.action.MedicationTreatment;
import org.hl7.qlim.action.Order;

public interface MedicationDispenseOrder
    extends MedicationTreatment, Order
{

    	// mixin


}
