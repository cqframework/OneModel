package org.hl7.qlim.Phenomenon;

/**
A group of related result values such as a laboratory result panel.  e.g., complete blood count, blood pressure
*/
public class ResultGroup
	extends ResultDetail {
// ObservationResult component
}
