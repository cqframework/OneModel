package org.hl7.qlim.Phenomenon;

/**
An inference made, about the patient's health, from other statements.
*/
public class Inference {
// Code inferenceMethod
// ClinicalStatement inferredFrom
}
