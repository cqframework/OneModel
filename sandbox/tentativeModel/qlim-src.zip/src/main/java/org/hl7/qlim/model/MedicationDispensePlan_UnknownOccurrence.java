
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfUnknownOccurrence;

public class MedicationDispensePlan_UnknownOccurrence
    extends StatementOfUnknownOccurrence
    implements MedicationDispensePlan
{

    

}
