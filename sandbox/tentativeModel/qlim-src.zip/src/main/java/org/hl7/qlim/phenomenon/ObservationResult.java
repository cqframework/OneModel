
package org.hl7.qlim.phenomenon;

import ca.uhn.fhir.model.primitive.CodeDt;
import org.hl7.qlim.entity.BodySite;


/**
 * Assertions and measurements made about a patient, device or other subject.
 * 
 * ObservationResults are a central element in healthcare, used to support diagnosis, monitor progress, determine baselines and patterns and even capture demographic characteristics. Fundamentally, observations are name/value pair assertions. Simple observation values, such a body temperature, are specified in the value attribute. Richer values, e.g., result panels, aggregate observations from diagnostic imaging, and microbiology sensitivity results,  are specified in the detailedResult attribute., 
 * 
 * This data type does not support the storage of the image or signal sequences such as electrocardiogram data.  However, the observations and interpretation made from the images and signals can be represented here.
 * 
 */
public class ObservationResult
    implements Phenomenon
{

    private BodySite bodySite;
    private CodeDt interpretation;
    private CodeDt method;
    private CodeDt name;
    private CodeDt reliability;
    private CodeDt status;
    private CodeDt validationMethod;
    private ResultDetail detailedResult;

    public BodySite getBodySite() {
        return bodySite;
    }

    public void setBodySite(BodySite value) {
        bodySite = value;
    }

    public CodeDt getInterpretation() {
        return interpretation;
    }

    public void setInterpretation(CodeDt value) {
        interpretation = value;
    }

    public CodeDt getMethod() {
        return method;
    }

    public void setMethod(CodeDt value) {
        method = value;
    }

    public CodeDt getName() {
        return name;
    }

    public void setName(CodeDt value) {
        name = value;
    }

    public CodeDt getReliability() {
        return reliability;
    }

    public void setReliability(CodeDt value) {
        reliability = value;
    }

    public CodeDt getStatus() {
        return status;
    }

    public void setStatus(CodeDt value) {
        status = value;
    }

    public CodeDt getValidationMethod() {
        return validationMethod;
    }

    public void setValidationMethod(CodeDt value) {
        validationMethod = value;
    }

    public ResultDetail getDetailedResult() {
        return detailedResult;
    }

    public void setDetailedResult(ResultDetail value) {
        detailedResult = value;
    }
    
	// Value value

}
