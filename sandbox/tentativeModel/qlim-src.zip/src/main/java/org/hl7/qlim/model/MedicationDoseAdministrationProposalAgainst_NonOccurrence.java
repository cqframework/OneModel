
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfNonOccurrence;

public class MedicationDoseAdministrationProposalAgainst_NonOccurrence
    extends StatementOfNonOccurrence
    implements MedicationDoseAdministrationProposalAgainst
{

    

}
