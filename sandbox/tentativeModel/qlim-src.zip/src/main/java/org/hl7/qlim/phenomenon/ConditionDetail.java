
package org.hl7.qlim.phenomenon;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Further detail about the condition, for example, intensity of pain.
 * 
 */
public class ConditionDetail {

    private CodeDt property;

    public CodeDt getProperty() {
        return property;
    }

    public void setProperty(CodeDt value) {
        property = value;
    }
    
	// Value value

}
