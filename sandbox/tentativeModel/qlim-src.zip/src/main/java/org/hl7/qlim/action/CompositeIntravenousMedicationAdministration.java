
package org.hl7.qlim.action;

import java.util.ArrayList;
import java.util.List;
import org.hl7.qlim.entity.Constituent;


/**
 * Parameters for IV fluid administration that may consist of one or more additives mixed into a diluent. Additives and diluents are represented as constituents with the appropriate constituentType.
 * 
 */
public class CompositeIntravenousMedicationAdministration
    extends MedicationParameters
{

    private List<Constituent> constituent;

    public List<Constituent> getConstituent() {
        if (constituent == null) {
            constituent = new ArrayList<Constituent>();
        }
        return constituent;
    }

    public void setConstituent(List<Constituent> value) {
        constituent = value;
    }
    

}
