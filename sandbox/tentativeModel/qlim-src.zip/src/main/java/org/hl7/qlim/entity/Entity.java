
package org.hl7.qlim.entity;

import java.util.ArrayList;
import java.util.List;

public class Entity {

    private List<EntityCharacteristic> characteristic;

    public List<EntityCharacteristic> getCharacteristic() {
        if (characteristic == null) {
            characteristic = new ArrayList<EntityCharacteristic>();
        }
        return characteristic;
    }

    public void setCharacteristic(List<EntityCharacteristic> value) {
        characteristic = value;
    }
    

}
