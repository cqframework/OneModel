
package org.hl7.qlim.action;



/**
 * Description of action that is planned to be performed. Typically, this would include a time at which the action is scheduled to be performed.
 * 
 */
public interface Plan
    extends Action
{

    	// mixin

	// TimePeriod expectedPerformanceTime
	// TimePoint plannedAtTime

}
