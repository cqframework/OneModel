package org.hl7.qlim.Entity;

public class Entity {
// EntityCharacteristic characteristic
}
