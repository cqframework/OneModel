
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;

public class ProcedureProposal_Occurrence
    extends StatementOfOccurrence
    implements ProcedureProposal
{

    

}
