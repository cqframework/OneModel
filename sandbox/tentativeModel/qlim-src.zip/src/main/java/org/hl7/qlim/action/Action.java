
package org.hl7.qlim.action;

import org.hl7.qlim.core.StatementTopic;


/**
 * Description of a healthcare action, independent of the performance of the action.
 * 
 */
public interface Action
    extends StatementTopic
{

    	// mixin

	// Participant actionParticipant [0..*]
	// Code actionReason
	// ActionStatus currentStatus
	// Code patientPreference
	// Code providerPreference
	// ActionStatus statusHistory [0..*]
	// ActionModality focus

}
