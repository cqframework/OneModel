
package org.hl7.qlim.action;

import org.hl7.qlim.complexDataType.Schedule;
import org.hl7.qlim.entity.BodySite;
import org.hl7.qlim.entity.Device;


/**
 * Application or use of equipment or device for the patient. E.g., wheelchair, Holter monitor, pacemaker, intra-uterine contraceptive device
 * 
 */
public class DeviceUse
    implements ActionModality
{

    private Schedule applicationSchedule;
    private BodySite targetBodySite;
    private Device device;

    public Schedule getApplicationSchedule() {
        return applicationSchedule;
    }

    public void setApplicationSchedule(Schedule value) {
        applicationSchedule = value;
    }

    public BodySite getTargetBodySite() {
        return targetBodySite;
    }

    public void setTargetBodySite(BodySite value) {
        targetBodySite = value;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device value) {
        device = value;
    }
    

}
