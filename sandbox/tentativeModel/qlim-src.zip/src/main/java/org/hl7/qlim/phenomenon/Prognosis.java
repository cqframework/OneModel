
package org.hl7.qlim.phenomenon;

import ca.uhn.fhir.model.primitive.CodeDt;

public class Prognosis
    implements Phenomenon
{

    private CodeDt condition;
    private Inference inference;

    public CodeDt getCondition() {
        return condition;
    }

    public void setCondition(CodeDt value) {
        condition = value;
    }

    public Inference getInference() {
        return inference;
    }

    public void setInference(Inference value) {
        inference = value;
    }
    
	// Value likelihood
	// Period within

}
