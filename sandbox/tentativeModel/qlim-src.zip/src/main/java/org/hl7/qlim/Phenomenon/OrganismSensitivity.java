package org.hl7.qlim.Phenomenon;

/**
Sensitivity of an organism to a specified antimicrobial agent
*/
public class OrganismSensitivity {
// Substance antiMicrobialAgent
// Code organism
// Code sensitivity
}
