
package org.hl7.qlim.action;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Description of the participation of a patient in a recognized program of care such as a care plan, a chemotherapy protocol, or a clinical trial.
 * 
 */
public class CareProgram
    implements ActionModality
{

    private List<Goal> goals;
    private CodeDt participationStatus;
    private CodeDt programType;

    public List<Goal> getGoals() {
        if (goals == null) {
            goals = new ArrayList<Goal>();
        }
        return goals;
    }

    public void setGoals(List<Goal> value) {
        goals = value;
    }

    public CodeDt getParticipationStatus() {
        return participationStatus;
    }

    public void setParticipationStatus(CodeDt value) {
        participationStatus = value;
    }

    public CodeDt getProgramType() {
        return programType;
    }

    public void setProgramType(CodeDt value) {
        programType = value;
    }
    

}
