package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Action.Procedure;
import org.hl7.qlim.Action.Proposal;

public interface ProcedureProposal extends Procedure, Proposal {
// mixin
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
// TimePeriod expectedPerformanceTime
// TimePoint proposedAtTime
// Code urgency
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
}
