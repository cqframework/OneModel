package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Core.StatementOfUnknownOccurrence;
import org.hl7.qlim.Phenomenon.Condition;

public class Condition_UnknownOccurrence
	extends StatementOfUnknownOccurrence implements Condition {
// Text additionalText
// Encounter encounter
// ClinicalStatement predecessorStatement
// Code semanticType
// Person statementAuthor
// TimePoint statementDateTime
// Entity statementSource
// Patient subject
// ClinicalStatement successorStatement
// StatementTopic topic
// BodySite bodySite
// Code category
// TimePeriod effectiveTime
// code encounterRole
// Code name
// Code status
// ConditionDetail conditionDetail
// Period observedAtTime
}
