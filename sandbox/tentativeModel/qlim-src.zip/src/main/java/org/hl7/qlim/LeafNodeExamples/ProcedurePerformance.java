package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Action.Performance;
import org.hl7.qlim.Action.Procedure;

public interface ProcedurePerformance extends Performance, Procedure {
// mixin
// Code aspectPerformed
// Participant participant
// TimePeriod performedAtTime
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
}
