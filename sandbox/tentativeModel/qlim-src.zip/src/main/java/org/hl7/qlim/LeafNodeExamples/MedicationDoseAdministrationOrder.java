package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Action.Order;
import org.hl7.qlim.Action.MedicationTreatment;

public interface MedicationDoseAdministrationOrder extends Order, MedicationTreatment {
// mixin
// TimePeriod expectedPerformanceTime
// TimePoint orderedAtTime
// Code originationMode
// Code urgency
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
// Medication medication
// Dispense dispense
// Dosage dosage
// MedicationParameters details
}
