package org.hl7.qlim.Action;

/**
Parameters for specific types of medications that can be administered.
*/
public class MedicationParameters {
}
