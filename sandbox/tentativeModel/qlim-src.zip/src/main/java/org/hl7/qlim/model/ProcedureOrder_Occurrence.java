
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;

public class ProcedureOrder_Occurrence
    extends StatementOfOccurrence
    implements ProcedureOrder
{

    

}
