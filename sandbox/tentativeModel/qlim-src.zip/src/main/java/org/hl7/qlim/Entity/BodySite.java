package org.hl7.qlim.Entity;

/**
A location on a person's body.  E.g., left breast, heart.
*/
public class BodySite
	extends Entity {
// Code anatomicalLocation
// Code directionality
// Code laterality
// EntityCharacteristic characteristic
}
