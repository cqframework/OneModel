
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Details about the vaccine product administered to the patient
 * 
 */
public class Vaccine
    extends ManufacturedProduct
{

    private CodeDt vaccineType;

    public CodeDt getVaccineType() {
        return vaccineType;
    }

    public void setVaccineType(CodeDt value) {
        vaccineType = value;
    }
    

}
