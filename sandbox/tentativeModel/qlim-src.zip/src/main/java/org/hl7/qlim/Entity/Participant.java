package org.hl7.qlim.Entity;

/**
Person playing a specified role in an action.
*/
public class Participant
	extends Entity {
// Person individual
// Code participantRole
// EntityCharacteristic characteristic
}
