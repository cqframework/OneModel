package org.hl7.qlim.Entity;

/**
A manufactured item that is administered for a patient's nutrition
*/
public class NutritionProduct
	extends ManufacturedProduct {
// Code attribute
// Code type
// TimePoint expiry
// Text lotNumber
// Text manufacturerName
// EntityCharacteristic characteristic
}
