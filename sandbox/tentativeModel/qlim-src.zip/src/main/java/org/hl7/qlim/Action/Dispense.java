package org.hl7.qlim.Action;

/**
Details of the dispensation such as the days supply and quantity of medication (to be) dispensed.
*/
public class Dispense {
// Quantity amount
// TimePeriod dispenseTime
// Quantity numberOfRepeatsAllowed
}
