
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Information about a person that is involved in the care for a patient, but who is not the target of healthcare, nor has a professional responsibility in the care process.
 * 
 * RelatedPersons typically have a personal or non-healthcare-specific professional relationship to the patient. A <code>RelatedPerson</code> element is primarily used for attribution of information, since RelatedPersons are often a source of information about the patient. Example RelatedPersons are:
 * 
 * <ul>
 *  <li>A patient's wife or husband</li>
 *  <li>A patient's relatives or friends</li>
 *  <li>A neighbour bringing a patient to the hospital</li>
 *  <li>A patient's attorney or guardian</li>
 * </ul>
 * 
 */
public class RelatedPerson
    extends Person
{

    private CodeDt relationship;

    public CodeDt getRelationship() {
        return relationship;
    }

    public void setRelationship(CodeDt value) {
        relationship = value;
    }
    

}
