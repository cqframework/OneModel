package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Core.StatementOfNonOccurrence;

public class MedicationDoseAdministrationPlan_NonOccurrence
	extends StatementOfNonOccurrence implements MedicationDoseAdministrationPlan {
// Text additionalText
// Encounter encounter
// ClinicalStatement predecessorStatement
// Code semanticType
// Person statementAuthor
// TimePoint statementDateTime
// Entity statementSource
// Patient subject
// ClinicalStatement successorStatement
// StatementTopic topic
// TimePeriod expectedPerformanceTime
// TimePoint plannedAtTime
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
// Medication medication
// Dispense dispense
// Dosage dosage
// MedicationParameters details
}
