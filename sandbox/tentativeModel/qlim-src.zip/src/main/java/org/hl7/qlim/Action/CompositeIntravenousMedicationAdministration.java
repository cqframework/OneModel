package org.hl7.qlim.Action;

/**
Parameters for IV fluid administration that may consist of one or more additives mixed into a diluent. Additives and diluents are represented as constituents with the appropriate constituentType.
*/
public class CompositeIntravenousMedicationAdministration
	extends MedicationParameters {
// Constituent constituent
}
