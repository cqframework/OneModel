
package org.hl7.qlim.model;

import org.hl7.qlim.action.Order;
import org.hl7.qlim.action.Procedure;

public interface ProcedureOrder
    extends Order, Procedure
{

    	// mixin


}
