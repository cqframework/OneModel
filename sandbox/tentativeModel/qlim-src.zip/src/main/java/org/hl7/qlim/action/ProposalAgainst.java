
package org.hl7.qlim.action;


public interface ProposalAgainst
    extends Action
{

    	// mixin


}
