
package org.hl7.qlim.action;

import ca.uhn.fhir.model.dstu.composite.PeriodDt;
import ca.uhn.fhir.model.primitive.CodeDt;

public class Activity {

    private PeriodDt performedAtTime;
    private CodeDt task;

    public PeriodDt getPerformedAtTime() {
        return performedAtTime;
    }

    public void setPerformedAtTime(PeriodDt value) {
        performedAtTime = value;
    }

    public CodeDt getTask() {
        return task;
    }

    public void setTask(CodeDt value) {
        task = value;
    }
    

}
