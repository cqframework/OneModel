package org.hl7.qlim.Action;

/**
The proposal may be a recommendation from a clinical decision support system or advice from a consultation.
*/
public interface Proposal extends Action {
// mixin
// TimePeriod expectedPerformanceTime
// TimePoint proposedAtTime
// Code urgency
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
}
