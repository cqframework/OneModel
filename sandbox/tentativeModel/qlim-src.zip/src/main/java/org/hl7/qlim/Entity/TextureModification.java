package org.hl7.qlim.Entity;

/**
<code>TextureModification</code> specifies or modifies the texture for one or more types of food in a diet, e.g., ground, chopped, or puree. Texture modification is part of the diet specification and may have different textures ordered for different food groups, e.g., ground meat.
*/
public class TextureModification {
// Code foodType
// Code textureModifier
// Code textureType
}
