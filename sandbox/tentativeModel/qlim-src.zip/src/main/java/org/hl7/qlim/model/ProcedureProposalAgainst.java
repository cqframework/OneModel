
package org.hl7.qlim.model;

import org.hl7.qlim.action.Procedure;
import org.hl7.qlim.action.ProposalAgainst;

public interface ProcedureProposalAgainst
    extends Procedure, ProposalAgainst
{

    	// mixin


}
