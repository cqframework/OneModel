package org.hl7.qlim.Action;

import org.hl7.qlim.Core.StatementTopic;

/**
Description of a healthcare action, independent of the performance of the action.
*/
public interface Action extends StatementTopic {
// mixin
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
}
