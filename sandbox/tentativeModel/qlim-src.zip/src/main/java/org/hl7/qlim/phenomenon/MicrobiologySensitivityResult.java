
package org.hl7.qlim.phenomenon;

import java.util.ArrayList;
import java.util.List;


/**
 * Findings of the microbiology sensitivity test. This element is used to specify traditional, culture-isolate- run susceptibilities. It is not used to specify genetic methods for organism sensitivity.
 * 
 */
public class MicrobiologySensitivityResult
    extends ResultDetail
{

    private List<OrganismSensitivity> organismSensitivity;

    public List<OrganismSensitivity> getOrganismSensitivity() {
        if (organismSensitivity == null) {
            organismSensitivity = new ArrayList<OrganismSensitivity>();
        }
        return organismSensitivity;
    }

    public void setOrganismSensitivity(List<OrganismSensitivity> value) {
        organismSensitivity = value;
    }
    

}
