
package org.hl7.qlim.entity;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Person playing a specified role in an action.
 * 
 */
public class Participant
    extends Entity
{

    private Person individual;
    private List<CodeDt> participantRole;

    public Person getIndividual() {
        return individual;
    }

    public void setIndividual(Person value) {
        individual = value;
    }

    public List<CodeDt> getParticipantRole() {
        if (participantRole == null) {
            participantRole = new ArrayList<CodeDt>();
        }
        return participantRole;
    }

    public void setParticipantRole(List<CodeDt> value) {
        participantRole = value;
    }
    

}
