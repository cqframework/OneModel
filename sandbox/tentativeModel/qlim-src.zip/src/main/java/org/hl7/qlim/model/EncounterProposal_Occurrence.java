
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;

public class EncounterProposal_Occurrence
    extends StatementOfOccurrence
    implements EncounterProposal
{

    

}
