
package org.hl7.qlim.model;

import org.hl7.qlim.action.Encounter;
import org.hl7.qlim.action.Plan;

public interface EncounterPlan
    extends Encounter, Plan
{

    	// mixin


}
