package org.hl7.qlim.Entity;

/**
Information about the protocol(s) under which the vaccine was administered
*/
public class VaccinationProtocol {
// Organization authority
// Text description
// Quantity doseSequence
// Code doseStatus
// Code doseStatusReason
// Code doseTarget
// Text series
// Quantity seriesDoses
}
