
package org.hl7.qlim.phenomenon;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Significant health event or condition for people related to the subject, relevant in the context of care for the subject.
 * 
 * This information can be known to different levels of accuracy. Sometimes the exact condition ('asthma') is known, and sometimes it is less precise ('some sort of cancer'). Equally, sometimes the person can be identified ('my aunt agatha') and sometimes all that is known is that the person was an uncle.
 * 
 */
public class FamilyHistory
    implements Phenomenon
{

    private CodeDt condition;
    private CodeDt outcome;
    private CodeDt relationship;

    public CodeDt getCondition() {
        return condition;
    }

    public void setCondition(CodeDt value) {
        condition = value;
    }

    public CodeDt getOutcome() {
        return outcome;
    }

    public void setOutcome(CodeDt value) {
        outcome = value;
    }

    public CodeDt getRelationship() {
        return relationship;
    }

    public void setRelationship(CodeDt value) {
        relationship = value;
    }
    
	// Quantity deceasedAge
	// Quantity onsetAge

}
