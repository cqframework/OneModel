
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.DateTimeDt;


/**
 * Description of a product used in the care of a patient.
 * 
 */
public class ManufacturedProduct
    extends Entity
{

    private DateTimeDt expiry;
    private String lotNumber;
    private String manufacturerName;

    public DateTimeDt getExpiry() {
        return expiry;
    }

    public void setExpiry(DateTimeDt value) {
        expiry = value;
    }

    public String getLotNumber() {
        return lotNumber;
    }

    public void setLotNumber(String value) {
        lotNumber = value;
    }

    public String getManufacturerName() {
        return manufacturerName;
    }

    public void setManufacturerName(String value) {
        manufacturerName = value;
    }
    

}
