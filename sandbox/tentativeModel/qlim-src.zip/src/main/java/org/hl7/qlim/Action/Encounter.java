package org.hl7.qlim.Action;

/**
Description of an interaction between a patient and healthcare provider(s) for the purpose of providing healthcare service(s) or assessing the health status of a patient.
*/
public abstract class Encounter implements ActionModality {
// Code admissionSourceType
// Code class
// Code dischargeDisposition
// Schedule encounterSchedule
// Quantity length
// Location location
// Organization serviceProvider
// Code serviceType
}
