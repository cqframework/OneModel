
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;


/**
 * Aspect would REQUIRE code for Dispense
 * 
 * The dosage attribute/association in MedicationTreatment will be of type DosageAdministration
 * 
 */
public class MedicationDispensePerformance_Occurrence
    extends StatementOfOccurrence
    implements MedicationDispensePerformance
{

    

}
