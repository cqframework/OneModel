package org.hl7.qlim.Entity;

/**
Demographics and other administrative information about a person receiving care or other health-related services.

The data in the element covers the "who" information about the patient: it's attributes are focused on the demographic information necessary to support the administrative, financial and logistic procedures.
*/
public class Patient
	extends Person {
// Code ethnicity
// YesNo isDeceased
// Code maritalStatus
// Code race
// TimePoint timeOfDeath
// Address address
// TimePoint birthTime
// Code gender
// Text name
// TelecomAddress telecom
// EntityCharacteristic characteristic
}
