
package org.hl7.qlim.model;

import org.hl7.qlim.action.Procedure;
import org.hl7.qlim.action.Proposal;

public interface ProcedureProposal
    extends Procedure, Proposal
{

    	// mixin


}
