package org.hl7.qlim.Entity;

/**
Details for a physical place where services are provided and resources and participants may be stored, found, contained or accommodated.

A <code>Location</code> includes both incidental locations (a place which is used for healthcare without prior designation or authorization) and dedicated, formally appointed locations. Locations may be private, public, mobile or fixed and scale from small freezers to full hospital buildings or parking garages.

Examples of Locations are:

Building, ward, corridor or room
Freezer, incubator
Vehicle or lift
Home, shed, or a garage
Road, parking place, a park
*/
public class Location
	extends Entity {
// Address address
// Code function
// Text name
// Location partOf
// TelecomAddress telecom
// EntityCharacteristic characteristic
}
