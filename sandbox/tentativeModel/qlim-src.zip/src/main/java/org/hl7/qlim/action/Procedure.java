
package org.hl7.qlim.action;



/**
 * A procedure is an activity that is performed with or on a patient as part of the provision of care. This can be a physical 'thing' like an operation, or less invasive like counseling or hypnotherapy. Examples include surgical procedures, diagnostic procedures, endoscopic procedures, biopsies, and exclude things for which there are specific types of action descriptors defined, such as those for immunizations, medication administrations, nutrition administration, and application of devices.
 * 
 */
public interface Procedure
    extends ActionModality
{

    	// mixin

	// BodySite approachBodySite
	// Code procedureCode
	// Code procedureMethod
	// Schedule procedureSchedule
	// BodySite targetBodySite

}
