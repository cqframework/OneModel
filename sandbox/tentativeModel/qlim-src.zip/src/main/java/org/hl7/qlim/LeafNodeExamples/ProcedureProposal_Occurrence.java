package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Core.StatementOfOccurrence;

public class ProcedureProposal_Occurrence
	extends StatementOfOccurrence implements ProcedureProposal {
// Text additionalText
// Encounter encounter
// ClinicalStatement predecessorStatement
// Code semanticType
// Person statementAuthor
// TimePoint statementDateTime
// Entity statementSource
// Patient subject
// ClinicalStatement successorStatement
// StatementTopic topic
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
// TimePeriod expectedPerformanceTime
// TimePoint proposedAtTime
// Code urgency
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
}
