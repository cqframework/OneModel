
package org.hl7.qlim.action;

import ca.uhn.fhir.model.primitive.CodeDt;
import org.hl7.qlim.entity.VaccinationProtocol;
import org.hl7.qlim.entity.Vaccine;


/**
 * Descriptor for the administration of vaccines to patients across all healthcare disciplines in all care settings and all regions. This does not include the administration of non-vaccine agents, even those that may have or claim immunological effects.
 * 
 */
public class Immunization
    implements ActionModality
{

    private CodeDt reported;
    private DosageInstruction dosageInstruction;
    private VaccinationProtocol protocol;
    private Vaccine vaccine;

    public CodeDt getReported() {
        return reported;
    }

    public void setReported(CodeDt value) {
        reported = value;
    }

    public DosageInstruction getDosageInstruction() {
        return dosageInstruction;
    }

    public void setDosageInstruction(DosageInstruction value) {
        dosageInstruction = value;
    }

    public VaccinationProtocol getProtocol() {
        return protocol;
    }

    public void setProtocol(VaccinationProtocol value) {
        protocol = value;
    }

    public Vaccine getVaccine() {
        return vaccine;
    }

    public void setVaccine(Vaccine value) {
        vaccine = value;
    }
    

}
