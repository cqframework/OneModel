
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;

public class MedicationDoseAdministrationOrder_Occurrence
    extends StatementOfOccurrence
    implements MedicationDoseAdministrationOrder
{

    

}
