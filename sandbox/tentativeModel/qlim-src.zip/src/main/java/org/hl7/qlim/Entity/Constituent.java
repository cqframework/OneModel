package org.hl7.qlim.Entity;

/**
A component of a multi-component substance administration. May be an additive in a composite IV.
*/
public class Constituent {
// MedicationIngredient constituent
// Code constituentType
}
