
package org.hl7.qlim.core;


public class StatementOfUnknownOccurrence
    extends ClinicalStatement
{

    

}
