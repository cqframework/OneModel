
package org.hl7.qlim.entity;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Primarily used for identification and definition of <code>Medication</code>, but also covers ingredients and packaging.
 * 
 */
public class Medication
    extends ManufacturedProduct
{

    private CodeDt code;
    private CodeDt form;
    private boolean isBrand;
    private List<MedicationIngredient> ingredient;

    public CodeDt getCode() {
        return code;
    }

    public void setCode(CodeDt value) {
        code = value;
    }

    public CodeDt getForm() {
        return form;
    }

    public void setForm(CodeDt value) {
        form = value;
    }

    public boolean getIsBrand() {
        return isBrand;
    }

    public void setIsBrand(boolean value) {
        isBrand = value;
    }

    public List<MedicationIngredient> getIngredient() {
        if (ingredient == null) {
            ingredient = new ArrayList<MedicationIngredient>();
        }
        return ingredient;
    }

    public void setIngredient(List<MedicationIngredient> value) {
        ingredient = value;
    }
    

}
