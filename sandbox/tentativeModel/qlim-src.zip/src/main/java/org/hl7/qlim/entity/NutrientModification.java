
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Nutrient modifications allows specification of constraints on the quantity of components of diet. 
 * 
 * <code>NutrientModification</code> consists of the nutrient (e.g., Sodium) and the amount in the diet (e.g., 20-30g).
 * 
 */
public class NutrientModification {

    private CodeDt nutrientType;

    public CodeDt getNutrientType() {
        return nutrientType;
    }

    public void setNutrientType(CodeDt value) {
        nutrientType = value;
    }
    
	// IntervalOfQuantity quantity

}
