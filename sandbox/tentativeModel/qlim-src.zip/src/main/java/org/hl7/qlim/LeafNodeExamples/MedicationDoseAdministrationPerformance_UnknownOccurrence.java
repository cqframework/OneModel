package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Core.StatementOfUnknownOccurrence;

public class MedicationDoseAdministrationPerformance_UnknownOccurrence
	extends StatementOfUnknownOccurrence implements MedicationDoseAdministrationPerformance {
// Text additionalText
// Encounter encounter
// ClinicalStatement predecessorStatement
// Code semanticType
// Person statementAuthor
// TimePoint statementDateTime
// Entity statementSource
// Patient subject
// ClinicalStatement successorStatement
// StatementTopic topic
// Code aspectPerformed
// Participant participant
// TimePeriod performedAtTime
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
// Medication medication
// Dispense dispense
// Dosage dosage
// MedicationParameters details
}
