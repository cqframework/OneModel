
package org.hl7.qlim.action;



/**
 * A description of the action of prescribing or administering medication to a patient.
 * 
 */
public interface MedicationTreatment
    extends ActionModality
{

    	// mixin

	// Medication medication
	// Dispense dispense
	// Dosage dosage [0..*]
	// MedicationParameters details

}
