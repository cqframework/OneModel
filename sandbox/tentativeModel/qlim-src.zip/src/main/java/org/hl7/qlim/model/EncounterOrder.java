
package org.hl7.qlim.model;

import org.hl7.qlim.action.Encounter;
import org.hl7.qlim.action.Order;

public interface EncounterOrder
    extends Encounter, Order
{

    	// mixin


}
