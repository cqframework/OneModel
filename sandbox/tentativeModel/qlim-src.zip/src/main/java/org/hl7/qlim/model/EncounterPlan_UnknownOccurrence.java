
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfUnknownOccurrence;

public class EncounterPlan_UnknownOccurrence
    extends StatementOfUnknownOccurrence
    implements EncounterPlan
{

    

}
