
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;

public class ProcedurePlan_Occurrence
    extends StatementOfOccurrence
    implements ProcedurePlan
{

    

}
