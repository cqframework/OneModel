
package org.hl7.qlim.phenomenon;



/**
 * Result values that have more complex structures than can be represented by the simple value attribute.
 * 
 * It is expected that this general type will be extended for representation of specific type of result values.
 * 
 */
public class ResultDetail {

    

}
