
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Information about the protocol(s) under which the vaccine was administered
 * 
 */
public class VaccinationProtocol {

    private Organization authority;
    private String description;
    private CodeDt doseStatus;
    private CodeDt doseStatusReason;
    private CodeDt doseTarget;
    private String series;

    public Organization getAuthority() {
        return authority;
    }

    public void setAuthority(Organization value) {
        authority = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String value) {
        description = value;
    }

    public CodeDt getDoseStatus() {
        return doseStatus;
    }

    public void setDoseStatus(CodeDt value) {
        doseStatus = value;
    }

    public CodeDt getDoseStatusReason() {
        return doseStatusReason;
    }

    public void setDoseStatusReason(CodeDt value) {
        doseStatusReason = value;
    }

    public CodeDt getDoseTarget() {
        return doseTarget;
    }

    public void setDoseTarget(CodeDt value) {
        doseTarget = value;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String value) {
        series = value;
    }
    
	// Quantity doseSequence
	// Quantity seriesDoses

}
