package org.hl7.qlim.Action;

/**
Application or use of equipment or device for the patient. E.g., wheelchair, Holter monitor, pacemaker, intra-uterine contraceptive device
*/
public class DeviceUse implements ActionModality {
// Schedule applicationSchedule
// BodySite targetBodySite
// Device device
}
