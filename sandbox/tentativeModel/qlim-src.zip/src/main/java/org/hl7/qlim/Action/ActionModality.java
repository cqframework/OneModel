package org.hl7.qlim.Action;

/**
The object of an action, the specific thing that is being done or proposed.
*/
public interface ActionModality {
// mixin
}
