
package org.hl7.qlim.entity;



/**
 * The parameters that are specific to different types of procedures.
 * 
 */
public class ProcedureParameters {

    

}
