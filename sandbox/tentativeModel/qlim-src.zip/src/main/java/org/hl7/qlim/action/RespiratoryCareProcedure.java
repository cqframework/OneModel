
package org.hl7.qlim.action;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Procedures that encompass supplemental oxygen (eg, nasal cannula, face mask), BiPAP/CPAP, and mechanical ventilation.  
 * 
 * Note: While these are vastly different respiratory care concepts, the associated data elements can be constrained through templates.
 * 
 */
public abstract class RespiratoryCareProcedure
    implements Procedure
{

    private CodeDt isolationCode;
    private CodeDt ventilatorMode;

    public CodeDt getIsolationCode() {
        return isolationCode;
    }

    public void setIsolationCode(CodeDt value) {
        isolationCode = value;
    }

    public CodeDt getVentilatorMode() {
        return ventilatorMode;
    }

    public void setVentilatorMode(CodeDt value) {
        ventilatorMode = value;
    }
    
	// IntervalOfQuantity ePAP
	// IntervalOfQuantity fiO2
	// IntervalOfQuantity inspiratoryTime
	// IntervalOfQuantity iPAP
	// IntervalOfQuantity oxygenFlowRate
	// IntervalOfQuantity peakFlowRate
	// IntervalOfQuantity peakInspiratoryPressure
	// IntervalOfQuantity pEEP
	// IntervalOfQuantity pressureSupport
	// IntervalOfQuantity respiratoryRate
	// IntervalOfQuantity spO2Range
	// IntervalOfQuantity spO2Titration
	// IntervalOfQuantity tidalVolume

}
