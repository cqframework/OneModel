package org.hl7.qlim.Entity;

/**
The composition of the medication.
*/
public class MedicationIngredient {
// Quantity amount
// Code item
}
