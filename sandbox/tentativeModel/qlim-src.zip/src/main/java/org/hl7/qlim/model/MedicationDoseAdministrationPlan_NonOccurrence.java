
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfNonOccurrence;

public class MedicationDoseAdministrationPlan_NonOccurrence
    extends StatementOfNonOccurrence
    implements MedicationDoseAdministrationPlan
{

    

}
