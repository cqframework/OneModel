
package org.hl7.qlim.model;

import org.hl7.qlim.action.MedicationTreatment;
import org.hl7.qlim.action.Performance;

public interface MedicationDispensePerformance
    extends MedicationTreatment, Performance
{

    	// mixin


}
