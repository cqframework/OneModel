package org.hl7.qlim.Phenomenon;

public class Prognosis implements Phenomenon {
// Code condition
// Inference inference
// Value likelihood
// Period within
// Period observedAtTime
}
