
package org.hl7.qlim.core;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.primitive.CodeDt;
import ca.uhn.fhir.model.primitive.DateTimeDt;
import org.hl7.qlim.action.Encounter;
import org.hl7.qlim.entity.Entity;
import org.hl7.qlim.entity.Patient;
import org.hl7.qlim.entity.Person;

public abstract class ClinicalStatement {

    private String additionalText;
    private Encounter encounter;
    private List<ClinicalStatement> predecessorStatement;
    private List<CodeDt> semanticType;
    private Person statementAuthor;
    private DateTimeDt statementDateTime;
    private Entity statementSource;
    private Patient subject;
    private List<ClinicalStatement> successorStatement;
    private StatementTopic topic;

    public String getAdditionalText() {
        return additionalText;
    }

    public void setAdditionalText(String value) {
        additionalText = value;
    }

    public Encounter getEncounter() {
        return encounter;
    }

    public void setEncounter(Encounter value) {
        encounter = value;
    }

    public List<ClinicalStatement> getPredecessorStatement() {
        if (predecessorStatement == null) {
            predecessorStatement = new ArrayList<ClinicalStatement>();
        }
        return predecessorStatement;
    }

    public void setPredecessorStatement(List<ClinicalStatement> value) {
        predecessorStatement = value;
    }

    public List<CodeDt> getSemanticType() {
        if (semanticType == null) {
            semanticType = new ArrayList<CodeDt>();
        }
        return semanticType;
    }

    public void setSemanticType(List<CodeDt> value) {
        semanticType = value;
    }

    public Person getStatementAuthor() {
        return statementAuthor;
    }

    public void setStatementAuthor(Person value) {
        statementAuthor = value;
    }

    public DateTimeDt getStatementDateTime() {
        return statementDateTime;
    }

    public void setStatementDateTime(DateTimeDt value) {
        statementDateTime = value;
    }

    public Entity getStatementSource() {
        return statementSource;
    }

    public void setStatementSource(Entity value) {
        statementSource = value;
    }

    public Patient getSubject() {
        return subject;
    }

    public void setSubject(Patient value) {
        subject = value;
    }

    public List<ClinicalStatement> getSuccessorStatement() {
        if (successorStatement == null) {
            successorStatement = new ArrayList<ClinicalStatement>();
        }
        return successorStatement;
    }

    public void setSuccessorStatement(List<ClinicalStatement> value) {
        successorStatement = value;
    }

    public StatementTopic getTopic() {
        return topic;
    }

    public void setTopic(StatementTopic value) {
        topic = value;
    }
    

}
