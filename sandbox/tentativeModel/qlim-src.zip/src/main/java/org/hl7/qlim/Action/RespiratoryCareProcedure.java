package org.hl7.qlim.Action;

/**
Procedures that encompass supplemental oxygen (eg, nasal cannula, face mask), BiPAP/CPAP, and mechanical ventilation.  

Note: While these are vastly different respiratory care concepts, the associated data elements can be constrained through templates.
*/
public abstract class RespiratoryCareProcedure implements Procedure {
// IntervalOfQuantity ePAP
// IntervalOfQuantity fiO2
// IntervalOfQuantity inspiratoryTime
// IntervalOfQuantity iPAP
// Code isolationCode
// IntervalOfQuantity oxygenFlowRate
// IntervalOfQuantity peakFlowRate
// IntervalOfQuantity peakInspiratoryPressure
// IntervalOfQuantity pEEP
// IntervalOfQuantity pressureSupport
// IntervalOfQuantity respiratoryRate
// IntervalOfQuantity spO2Range
// IntervalOfQuantity spO2Titration
// IntervalOfQuantity tidalVolume
// Code ventilatorMode
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
}
