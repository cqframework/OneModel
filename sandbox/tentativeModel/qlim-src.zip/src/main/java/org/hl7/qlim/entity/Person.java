
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;
import ca.uhn.fhir.model.primitive.DateTimeDt;


/**
 * Demographic and identification information for an individual.
 * 
 * Additional attributes to be added in future versions.
 * 
 */
public abstract class Person
    extends Entity
{

    private DateTimeDt birthTime;
    private CodeDt gender;
    private String name;

    public DateTimeDt getBirthTime() {
        return birthTime;
    }

    public void setBirthTime(DateTimeDt value) {
        birthTime = value;
    }

    public CodeDt getGender() {
        return gender;
    }

    public void setGender(CodeDt value) {
        gender = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String value) {
        name = value;
    }
    
	// Address address
	// TelecomAddress telecom

}
