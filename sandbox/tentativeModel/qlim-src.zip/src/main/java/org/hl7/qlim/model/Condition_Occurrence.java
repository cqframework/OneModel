
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;
import org.hl7.qlim.phenomenon.Condition;

public class Condition_Occurrence
    extends StatementOfOccurrence
    implements Condition
{

    

}
