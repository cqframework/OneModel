package org.hl7.qlim.ComplexDataType;

/**
The recurrence pattern of events, e.g., three times a day after meals. 

A schedule that specifies an event that may occur multiple times. Schedules should not be used to record when events did happen but rather when actions or events are expected or requested to occur. 

A schedule can be either a list of 'calendar time' events - periods on which the event ought to occur, or a single event with repeating criteria, or just repeating criteria with no actual event as represented by the 'cycle' concept and attribute.
*/
public class Schedule {
// Cycle cycle
// TimePeriod event
}
