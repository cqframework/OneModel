package org.hl7.qlim.Action;

/**
Parameters for an Imaging examination. For instance, Chest Radiograph - PA and Lateral.
*/
public class ImagingProcedure implements Procedure {
// MedicationTreatment contrast
// Code isolationCode
// YesNo portableExam
// YesNo sedation
// Code stressor
// Code transportMode
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
}
