
package org.hl7.qlim.phenomenon;

import ca.uhn.fhir.model.dstu.composite.CodeableConceptDt;
import ca.uhn.fhir.model.dstu.composite.PeriodDt;
import ca.uhn.fhir.model.primitive.CodeDt;
import org.hl7.qlim.core.StatementOfOccurrence;
import org.hl7.qlim.entity.BodySite;

public class AdverseEvent
    implements Phenomenon
{

    private CodeDt agent;
    private BodySite bodySite;
    private CodeDt category;
    private Condition conditionDetail;
    private PeriodDt effectiveTime;
    private CodeableConceptDt name;
    private StatementOfOccurrence precedingExposure;
    private CodeDt status;

    public CodeDt getAgent() {
        return agent;
    }

    public void setAgent(CodeDt value) {
        agent = value;
    }

    public BodySite getBodySite() {
        return bodySite;
    }

    public void setBodySite(BodySite value) {
        bodySite = value;
    }

    public CodeDt getCategory() {
        return category;
    }

    public void setCategory(CodeDt value) {
        category = value;
    }

    public Condition getConditionDetail() {
        return conditionDetail;
    }

    public void setConditionDetail(Condition value) {
        conditionDetail = value;
    }

    public PeriodDt getEffectiveTime() {
        return effectiveTime;
    }

    public void setEffectiveTime(PeriodDt value) {
        effectiveTime = value;
    }

    public CodeableConceptDt getName() {
        return name;
    }

    public void setName(CodeableConceptDt value) {
        name = value;
    }

    public StatementOfOccurrence getPrecedingExposure() {
        return precedingExposure;
    }

    public void setPrecedingExposure(StatementOfOccurrence value) {
        precedingExposure = value;
    }

    public CodeDt getStatus() {
        return status;
    }

    public void setStatus(CodeDt value) {
        status = value;
    }
    

}
