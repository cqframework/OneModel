package org.hl7.qlim.Action;

/**
A communication is a message sent between a sender and a recipient for a purpose and about a topic. 
*/
public class Communication implements ActionModality {
// Code medium
// Text message
// Entity recipient
// Entity sender
// ClinicalStatement topic
}
