
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * A component of a multi-component substance administration. May be an additive in a composite IV.
 * 
 */
public class Constituent {

    private MedicationIngredient constituent;
    private CodeDt constituentType;

    public MedicationIngredient getConstituent() {
        return constituent;
    }

    public void setConstituent(MedicationIngredient value) {
        constituent = value;
    }

    public CodeDt getConstituentType() {
        return constituentType;
    }

    public void setConstituentType(CodeDt value) {
        constituentType = value;
    }
    

}
