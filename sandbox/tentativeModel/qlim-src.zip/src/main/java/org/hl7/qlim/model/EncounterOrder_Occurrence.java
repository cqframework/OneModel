
package org.hl7.qlim.model;


public class EncounterOrder_Occurrence {

    

}
