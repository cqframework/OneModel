
package org.hl7.qlim.action;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Parameters for an Imaging examination. For instance, Chest Radiograph - PA and Lateral.
 * 
 */
public class ImagingProcedure
    implements Procedure
{

    private MedicationTreatment contrast;
    private CodeDt isolationCode;
    private boolean portableExam;
    private boolean sedation;
    private CodeDt stressor;
    private CodeDt transportMode;

    public MedicationTreatment getContrast() {
        return contrast;
    }

    public void setContrast(MedicationTreatment value) {
        contrast = value;
    }

    public CodeDt getIsolationCode() {
        return isolationCode;
    }

    public void setIsolationCode(CodeDt value) {
        isolationCode = value;
    }

    public boolean getPortableExam() {
        return portableExam;
    }

    public void setPortableExam(boolean value) {
        portableExam = value;
    }

    public boolean getSedation() {
        return sedation;
    }

    public void setSedation(boolean value) {
        sedation = value;
    }

    public CodeDt getStressor() {
        return stressor;
    }

    public void setStressor(CodeDt value) {
        stressor = value;
    }

    public CodeDt getTransportMode() {
        return transportMode;
    }

    public void setTransportMode(CodeDt value) {
        transportMode = value;
    }
    

}
