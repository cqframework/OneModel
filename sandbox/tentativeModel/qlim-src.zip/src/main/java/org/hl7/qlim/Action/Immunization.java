package org.hl7.qlim.Action;

/**
Descriptor for the administration of vaccines to patients across all healthcare disciplines in all care settings and all regions. This does not include the administration of non-vaccine agents, even those that may have or claim immunological effects.
*/
public class Immunization implements ActionModality {
// Code reported
// DosageInstruction dosageInstruction
// VaccinationProtocol protocol
// Vaccine vaccine
}
