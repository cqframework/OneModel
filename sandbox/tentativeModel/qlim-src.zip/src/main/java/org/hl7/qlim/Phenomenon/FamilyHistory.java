package org.hl7.qlim.Phenomenon;

/**
Significant health event or condition for people related to the subject, relevant in the context of care for the subject.

This information can be known to different levels of accuracy. Sometimes the exact condition ('asthma') is known, and sometimes it is less precise ('some sort of cancer'). Equally, sometimes the person can be identified ('my aunt agatha') and sometimes all that is known is that the person was an uncle.
*/
public class FamilyHistory implements Phenomenon {
// Code condition
// Quantity deceasedAge
// Quantity onsetAge
// Code outcome
// Code relationship
// Period observedAtTime
}
