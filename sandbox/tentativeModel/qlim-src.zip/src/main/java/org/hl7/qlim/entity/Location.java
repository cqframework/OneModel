
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Details for a physical place where services are provided and resources and participants may be stored, found, contained or accommodated.
 * 
 * A <code>Location</code> includes both incidental locations (a place which is used for healthcare without prior designation or authorization) and dedicated, formally appointed locations. Locations may be private, public, mobile or fixed and scale from small freezers to full hospital buildings or parking garages.
 * 
 * Examples of Locations are:
 * 
 * Building, ward, corridor or room
 * Freezer, incubator
 * Vehicle or lift
 * Home, shed, or a garage
 * Road, parking place, a park
 * 
 */
public class Location
    extends Entity
{

    private CodeDt function;
    private String name;
    private Location partOf;

    public CodeDt getFunction() {
        return function;
    }

    public void setFunction(CodeDt value) {
        function = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String value) {
        name = value;
    }

    public Location getPartOf() {
        return partOf;
    }

    public void setPartOf(Location value) {
        partOf = value;
    }
    
	// Address address
	// TelecomAddress telecom

}
