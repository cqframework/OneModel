
package org.hl7.qlim.entity;



/**
 * The details of the nutrition item, with specific attributes depending on the mode by which the nutrition is administered.
 * 
 */
public abstract class NutritionItem
    extends Entity
{

    

}
