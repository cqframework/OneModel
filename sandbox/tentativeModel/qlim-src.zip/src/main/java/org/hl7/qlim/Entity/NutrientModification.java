package org.hl7.qlim.Entity;

/**
Nutrient modifications allows specification of constraints on the quantity of components of diet. 

<code>NutrientModification</code> consists of the nutrient (e.g., Sodium) and the amount in the diet (e.g., 20-30g).
*/
public class NutrientModification {
// Code nutrientType
// IntervalOfQuantity quantity
}
