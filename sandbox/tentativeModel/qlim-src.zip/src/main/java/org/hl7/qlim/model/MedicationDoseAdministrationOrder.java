
package org.hl7.qlim.model;

import org.hl7.qlim.action.MedicationTreatment;
import org.hl7.qlim.action.Order;

public interface MedicationDoseAdministrationOrder
    extends MedicationTreatment, Order
{

    	// mixin


}
