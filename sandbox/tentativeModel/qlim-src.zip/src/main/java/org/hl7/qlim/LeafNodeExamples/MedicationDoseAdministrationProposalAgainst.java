package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Action.ProposalAgainst;
import org.hl7.qlim.Action.MedicationTreatment;

public interface MedicationDoseAdministrationProposalAgainst extends ProposalAgainst, MedicationTreatment {
// mixin
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
// Medication medication
// Dispense dispense
// Dosage dosage
// MedicationParameters details
}
