package org.hl7.qlim.Entity;

/**
Concept generally representing food and/or a nutritional supplement prepared from food ingredients that is self-administered by a patient and consumed orally. 


A patient can have only one effective oral diet at a time.
*/
public class OralDiet
	extends NutritionItem {
// Code dietType
// Code foodType
// Schedule frequency
// NutrientModification nutrient
// TextureModification texture
// EntityCharacteristic characteristic
}
