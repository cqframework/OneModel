package org.hl7.qlim.Core;

public interface StatementTopic {
// mixin
}
