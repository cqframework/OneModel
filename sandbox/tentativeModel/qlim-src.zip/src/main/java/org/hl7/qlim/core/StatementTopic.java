
package org.hl7.qlim.core;


public interface StatementTopic {

    	// mixin


}
