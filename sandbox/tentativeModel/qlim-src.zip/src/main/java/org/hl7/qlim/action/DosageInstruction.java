
package org.hl7.qlim.action;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * Indicates how the medication is to be administered to or used by the patient.
 * 
 */
public class DosageInstruction
    extends Dosage
{

    private CodeDt additionalInstructions;
    private String dosageInstructionsText;

    public CodeDt getAdditionalInstructions() {
        return additionalInstructions;
    }

    public void setAdditionalInstructions(CodeDt value) {
        additionalInstructions = value;
    }

    public String getDosageInstructionsText() {
        return dosageInstructionsText;
    }

    public void setDosageInstructionsText(String value) {
        dosageInstructionsText = value;
    }
    
	// Quantity maxDosePerPeriod

}
