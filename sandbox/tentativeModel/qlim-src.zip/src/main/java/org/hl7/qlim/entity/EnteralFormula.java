
package org.hl7.qlim.entity;

import org.hl7.qlim.action.DosageInstruction;


/**
 * A way to provide food through a tube placed in the nose, mouth, the stomach, or the small intestine. 
 * 
 */
public class EnteralFormula
    extends NutritionItem
{

    private NutritionProduct product;
    private DosageInstruction administration;

    public NutritionProduct getProduct() {
        return product;
    }

    public void setProduct(NutritionProduct value) {
        product = value;
    }

    public DosageInstruction getAdministration() {
        return administration;
    }

    public void setAdministration(DosageInstruction value) {
        administration = value;
    }
    
	// Quantity caloricDensity

}
