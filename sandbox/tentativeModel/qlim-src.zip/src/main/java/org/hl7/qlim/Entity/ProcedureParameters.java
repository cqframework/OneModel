package org.hl7.qlim.Entity;

/**
The parameters that are specific to different types of procedures.
*/
public class ProcedureParameters {
}
