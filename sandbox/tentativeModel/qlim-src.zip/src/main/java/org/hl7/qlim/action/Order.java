
package org.hl7.qlim.action;



/**
 * An order is an instruction by a healthcare provider to another healthcare provider to perform some action.
 * 
 */
public interface Order
    extends Action
{

    	// mixin

	// TimePeriod expectedPerformanceTime
	// TimePoint orderedAtTime
	// Code originationMode
	// Code urgency

}
