
package org.hl7.qlim.complexDataType;

import java.util.ArrayList;
import java.util.List;
import ca.uhn.fhir.model.dstu.composite.PeriodDt;


/**
 * The recurrence pattern of events, e.g., three times a day after meals. 
 * 
 * A schedule that specifies an event that may occur multiple times. Schedules should not be used to record when events did happen but rather when actions or events are expected or requested to occur. 
 * 
 * A schedule can be either a list of 'calendar time' events - periods on which the event ought to occur, or a single event with repeating criteria, or just repeating criteria with no actual event as represented by the 'cycle' concept and attribute.
 * 
 */
public class Schedule {

    private List<Cycle> cycle;
    private PeriodDt event;

    public List<Cycle> getCycle() {
        if (cycle == null) {
            cycle = new ArrayList<Cycle>();
        }
        return cycle;
    }

    public void setCycle(List<Cycle> value) {
        cycle = value;
    }

    public PeriodDt getEvent() {
        return event;
    }

    public void setEvent(PeriodDt value) {
        event = value;
    }
    

}
