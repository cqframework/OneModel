package org.hl7.qlim.Entity;

/**
Demographics and qualification information for an individual who is directly or indirectly involved in the provisioning of healthcare.

<code>Practitioner</code> covers all individuals who are engaged in the healthcare process and healthcare-related services as part of their professional responsibilities. This class is used for attribution of activities and responsibilities to these individuals. Practitioners include (but are not limited to):

<ul>
 <li>physicians, dentists, pharmacists</li>
 <li>physician assistants, nurses, scribes</li>
 <li>midwives, dietitians, therapists, optometrists, paramedics</li>
 <li>medical technicians, laboratory scientists, prosthetic technicians, radiographers</li>
 <li>social workers, professional home carers, official volunteers</li>
 <li>receptionists handling patient registration</li>
 <li>IT personnel merging or unmerging patient records</li>
</ul>
*/
public class Practitioner
	extends Person {
// Organization organization
// Code role
// Code speciality
// Address address
// TimePoint birthTime
// Code gender
// Text name
// TelecomAddress telecom
// EntityCharacteristic characteristic
}
