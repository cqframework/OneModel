package org.hl7.qlim.Phenomenon;

/**
Findings of the microbiology sensitivity test. This element is used to specify traditional, culture-isolate- run susceptibilities. It is not used to specify genetic methods for organism sensitivity.
*/
public class MicrobiologySensitivityResult
	extends ResultDetail {
// OrganismSensitivity organismSensitivity
}
