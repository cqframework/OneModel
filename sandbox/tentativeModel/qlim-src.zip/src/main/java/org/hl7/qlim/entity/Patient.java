
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;
import ca.uhn.fhir.model.primitive.DateTimeDt;


/**
 * Demographics and other administrative information about a person receiving care or other health-related services.
 * 
 * The data in the element covers the "who" information about the patient: it's attributes are focused on the demographic information necessary to support the administrative, financial and logistic procedures.
 * 
 */
public class Patient
    extends Person
{

    private CodeDt ethnicity;
    private boolean isDeceased;
    private CodeDt maritalStatus;
    private CodeDt race;
    private DateTimeDt timeOfDeath;

    public CodeDt getEthnicity() {
        return ethnicity;
    }

    public void setEthnicity(CodeDt value) {
        ethnicity = value;
    }

    public boolean getIsDeceased() {
        return isDeceased;
    }

    public void setIsDeceased(boolean value) {
        isDeceased = value;
    }

    public CodeDt getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(CodeDt value) {
        maritalStatus = value;
    }

    public CodeDt getRace() {
        return race;
    }

    public void setRace(CodeDt value) {
        race = value;
    }

    public DateTimeDt getTimeOfDeath() {
        return timeOfDeath;
    }

    public void setTimeOfDeath(DateTimeDt value) {
        timeOfDeath = value;
    }
    

}
