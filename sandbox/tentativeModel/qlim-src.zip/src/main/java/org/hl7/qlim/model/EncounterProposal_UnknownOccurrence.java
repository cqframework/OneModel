
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfUnknownOccurrence;

public class EncounterProposal_UnknownOccurrence
    extends StatementOfUnknownOccurrence
    implements EncounterProposal
{

    

}
