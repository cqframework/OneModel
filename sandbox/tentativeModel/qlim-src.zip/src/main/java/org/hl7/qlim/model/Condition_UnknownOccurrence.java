
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfUnknownOccurrence;
import org.hl7.qlim.phenomenon.Condition;

public class Condition_UnknownOccurrence
    extends StatementOfUnknownOccurrence
    implements Condition
{

    

}
