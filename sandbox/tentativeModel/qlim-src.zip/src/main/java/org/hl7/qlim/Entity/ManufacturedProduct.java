package org.hl7.qlim.Entity;

/**
Description of a product used in the care of a patient.
*/
public class ManufacturedProduct
	extends Entity {
// TimePoint expiry
// Text lotNumber
// Text manufacturerName
// EntityCharacteristic characteristic
}
