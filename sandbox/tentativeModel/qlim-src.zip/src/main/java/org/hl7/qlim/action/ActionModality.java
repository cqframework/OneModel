
package org.hl7.qlim.action;



/**
 * The object of an action, the specific thing that is being done or proposed.
 * 
 */
public interface ActionModality {

    	// mixin


}
