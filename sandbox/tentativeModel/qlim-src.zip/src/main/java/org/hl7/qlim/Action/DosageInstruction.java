package org.hl7.qlim.Action;

/**
Indicates how the medication is to be administered to or used by the patient.
*/
public class DosageInstruction
	extends Dosage {
// Code additionalInstructions
// Text dosageInstructionsText
// Quantity maxDosePerPeriod
// Schedule administrationSchedule
// BodySite administrationSite
// Code approachBodySite
// Code deliveryRoute
// Quantity doseQuantity
// Code doseType
// Quantity infuseOver
// Code method
// Quantity rate
}
