package org.hl7.qlim.LeafNodeExamples;

import org.hl7.qlim.Core.StatementOfUnknownOccurrence;

public class ProcedurePlan_UnknownOccurrence
	extends StatementOfUnknownOccurrence implements ProcedurePlan {
// Text additionalText
// Encounter encounter
// ClinicalStatement predecessorStatement
// Code semanticType
// Person statementAuthor
// TimePoint statementDateTime
// Entity statementSource
// Patient subject
// ClinicalStatement successorStatement
// StatementTopic topic
// TimePeriod expectedPerformanceTime
// TimePoint plannedAtTime
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
// BodySite approachBodySite
// Code procedureCode
// Code procedureMethod
// Schedule procedureSchedule
// BodySite targetBodySite
}
