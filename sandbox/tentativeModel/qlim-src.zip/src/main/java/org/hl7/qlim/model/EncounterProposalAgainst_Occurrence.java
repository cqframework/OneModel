
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;

public class EncounterProposalAgainst_Occurrence
    extends StatementOfOccurrence
    implements EncounterProposalAgainst
{

    

}
