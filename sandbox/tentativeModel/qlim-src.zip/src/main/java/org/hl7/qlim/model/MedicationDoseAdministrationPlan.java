
package org.hl7.qlim.model;

import org.hl7.qlim.action.MedicationTreatment;
import org.hl7.qlim.action.Plan;

public interface MedicationDoseAdministrationPlan
    extends MedicationTreatment, Plan
{

    	// mixin


}
