
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * The composition of the medication.
 * 
 */
public class MedicationIngredient {

    private CodeDt item;

    public CodeDt getItem() {
        return item;
    }

    public void setItem(CodeDt value) {
        item = value;
    }
    
	// Quantity amount

}
