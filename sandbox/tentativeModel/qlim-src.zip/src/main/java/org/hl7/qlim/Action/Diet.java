package org.hl7.qlim.Action;

/**
Description of diet/nutrition to be administered to a patient.
*/
public class Diet implements ActionModality {
// String foodModifier
// NutritionItem nutritionItem
}
