package org.hl7.qlim.Action;

/**
The actual performance or execution of a healthcare-related action, e.g., 3rd dose of Hepatitis B vaccine administered on Dec 4th 2012, appendectomy performed today.
*/
public interface Performance extends Action {
// mixin
// Code aspectPerformed
// Participant participant
// TimePeriod performedAtTime
// Participant actionParticipant
// Code actionReason
// ActionStatus currentStatus
// Code patientPreference
// Code providerPreference
// ActionStatus statusHistory
// ActionModality focus
}
