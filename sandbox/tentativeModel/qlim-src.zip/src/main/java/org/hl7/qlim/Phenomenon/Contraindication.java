package org.hl7.qlim.Phenomenon;

/**
Describes a contraindication to a healthcare related action, e.g., medication intake, procedure.

A contraindication is a specific situation in which a drug, procedure, or surgery should not be used because it may be harmful to the patient.
*/
public class Contraindication implements Phenomenon {
// Medication contraindicatedMedication
// Inference inference
// Period observedAtTime
}
