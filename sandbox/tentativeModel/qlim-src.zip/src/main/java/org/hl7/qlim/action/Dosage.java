
package org.hl7.qlim.action;

import ca.uhn.fhir.model.primitive.CodeDt;
import org.hl7.qlim.complexDataType.Schedule;
import org.hl7.qlim.entity.BodySite;

public abstract class Dosage {

    private Schedule administrationSchedule;
    private BodySite administrationSite;
    private CodeDt approachBodySite;
    private CodeDt deliveryRoute;
    private CodeDt doseType;
    private CodeDt method;

    public Schedule getAdministrationSchedule() {
        return administrationSchedule;
    }

    public void setAdministrationSchedule(Schedule value) {
        administrationSchedule = value;
    }

    public BodySite getAdministrationSite() {
        return administrationSite;
    }

    public void setAdministrationSite(BodySite value) {
        administrationSite = value;
    }

    public CodeDt getApproachBodySite() {
        return approachBodySite;
    }

    public void setApproachBodySite(CodeDt value) {
        approachBodySite = value;
    }

    public CodeDt getDeliveryRoute() {
        return deliveryRoute;
    }

    public void setDeliveryRoute(CodeDt value) {
        deliveryRoute = value;
    }

    public CodeDt getDoseType() {
        return doseType;
    }

    public void setDoseType(CodeDt value) {
        doseType = value;
    }

    public CodeDt getMethod() {
        return method;
    }

    public void setMethod(CodeDt value) {
        method = value;
    }
    
	// Quantity doseQuantity
	// Quantity infuseOver
	// Quantity rate

}
