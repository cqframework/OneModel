package org.hl7.qlim.Entity;

/**
Demographic and identification information for an individual.

Additional attributes to be added in future versions.
*/
public abstract class Person
	extends Entity {
// Address address
// TimePoint birthTime
// Code gender
// Text name
// TelecomAddress telecom
// EntityCharacteristic characteristic
}
