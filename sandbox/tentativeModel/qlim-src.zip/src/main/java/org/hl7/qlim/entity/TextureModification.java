
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * <code>TextureModification</code> specifies or modifies the texture for one or more types of food in a diet, e.g., ground, chopped, or puree. Texture modification is part of the diet specification and may have different textures ordered for different food groups, e.g., ground meat.
 * 
 */
public class TextureModification {

    private CodeDt foodType;
    private CodeDt textureModifier;
    private CodeDt textureType;

    public CodeDt getFoodType() {
        return foodType;
    }

    public void setFoodType(CodeDt value) {
        foodType = value;
    }

    public CodeDt getTextureModifier() {
        return textureModifier;
    }

    public void setTextureModifier(CodeDt value) {
        textureModifier = value;
    }

    public CodeDt getTextureType() {
        return textureType;
    }

    public void setTextureType(CodeDt value) {
        textureType = value;
    }
    

}
