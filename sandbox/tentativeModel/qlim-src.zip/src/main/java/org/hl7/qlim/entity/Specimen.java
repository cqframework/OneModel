
package org.hl7.qlim.entity;

import ca.uhn.fhir.model.primitive.CodeDt;


/**
 * A sample of tissue, blood, urine, water, air, etc., taken for the purposes of diagnostic examination or evaluation.
 * 
 */
public class Specimen
    extends Entity
{

    private CodeDt collectionMethod;
    private BodySite collectionSite;
    private Patient subject;
    private CodeDt type;

    public CodeDt getCollectionMethod() {
        return collectionMethod;
    }

    public void setCollectionMethod(CodeDt value) {
        collectionMethod = value;
    }

    public BodySite getCollectionSite() {
        return collectionSite;
    }

    public void setCollectionSite(BodySite value) {
        collectionSite = value;
    }

    public Patient getSubject() {
        return subject;
    }

    public void setSubject(Patient value) {
        subject = value;
    }

    public CodeDt getType() {
        return type;
    }

    public void setType(CodeDt value) {
        type = value;
    }
    

}
