
package org.hl7.qlim.model;

import org.hl7.qlim.core.StatementOfOccurrence;

public class EncounterPerformance_Occurrence
    extends StatementOfOccurrence
    implements EncounterPerformance
{

    

}
