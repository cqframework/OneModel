import static org.junit.Assert.*;

import ca.uhn.fhir.model.primitive.CodeDt;
import ca.uhn.fhir.model.primitive.DateTimeDt;
import org.hl7.qlim.core.ClinicalStatement;
import org.hl7.qlim.entity.Device;
import org.hl7.qlim.entity.Entity;
import org.hl7.qlim.entity.EntityCharacteristic;
import org.hl7.qlim.entity.Patient;
import org.hl7.qlim.model.Condition_Occurrence;
import org.hl7.qlim.model.EncounterPerformance_Occurrence;
import org.hl7.qlim.model.MedicationDispensePerformance_Occurrence;
import org.hl7.qlim.phenomenon.AdverseEvent;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TestCreate {

	@Test
	public void test() {

		EncounterPerformance_Occurrence encounter = new EncounterPerformance_Occurrence();
		Patient patient = new Patient();
		patient.setName("Smith, John");
		final EntityCharacteristic characteristic = new EntityCharacteristic();
		characteristic.setCode(new CodeDt("life is good"));
		characteristic.setPresence(true);
		patient.getCharacteristic().add(characteristic);
		patient.setGender(new CodeDt("M"));
		patient.setBirthTime(new DateTimeDt(new Date(1999, 0, 30, 5, 0)));
		encounter.setSubject(patient);

		Condition_Occurrence condition  = new Condition_Occurrence();
		condition.setSubject(patient);
		condition.setAdditionalText("foo");
		condition.setEncounter(encounter);
		condition.getSemanticType().add(new CodeDt("Condition, Active"));
		Entity source = new Device();
		condition.setStatementSource(source);
		assertTrue(condition.getPredecessorStatement().isEmpty());

		MedicationDispensePerformance_Occurrence medDispense = new MedicationDispensePerformance_Occurrence();
		medDispense.setAdditionalText("foo");
		medDispense.setEncounter(encounter);
		List<ClinicalStatement> predecessorStatements = new ArrayList<ClinicalStatement>(1);
		predecessorStatements.add(condition);
		condition.setPredecessorStatement(predecessorStatements);
		assertFalse(condition.getPredecessorStatement().isEmpty());
	}

}