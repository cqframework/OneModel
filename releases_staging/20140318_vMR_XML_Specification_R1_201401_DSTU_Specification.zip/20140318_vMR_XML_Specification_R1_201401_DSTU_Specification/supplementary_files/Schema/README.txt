Note that these XML Schemas were auto-generated from the HL7 vMR Logical Model, Release 2.  The only manual updates following the auto-generation are as follows:
- Removed excess/empty auto-generated <xs:sequence/> 
- Added root entry-point elements to all schemas except datatypes (note vMR element is lower case for first letter)
- Alphabetized order of schema complex types
- Formatted XML using "Prettty Print" feature of Altova XMLSpy