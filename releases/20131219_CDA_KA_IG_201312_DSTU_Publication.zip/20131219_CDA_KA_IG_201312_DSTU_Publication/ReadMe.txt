This package consists of:
- this ReadMe file
- the CDS Knowledge Artifact Implemenation Guide in 2 viewing formats - .docx and .pdf
     1. ONC_HeD_CDS Knowledge Artifact Implementation Guide.docx
     2. ONC_HeD_CDS Knowledge Artifact Implementation Guide.pdf
     3. Supplementary Files
     	a. Arden Mapping.docx: mapping between HeDS ECA artifact to an ArdenML 2.8 rule definition
	b. OrderSetElementMapping.xlsx: mapping between HL7 Order Sets and HeD Data Elements
     4. Examples
	This folder includes the Knowledge Artifact XML files, associated source documents, and a word document describing the examples.
     5. Schema
	This folder contains the Knowledge Artifact schema files.