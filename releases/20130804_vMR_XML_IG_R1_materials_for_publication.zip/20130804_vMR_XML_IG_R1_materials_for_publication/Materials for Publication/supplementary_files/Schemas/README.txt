Note that these XML Schemas were auto-generated from the HL7 vMR Domain Analysis Model (DAM), Release 2.  The only manual updates following the auto-generation are as follows:
- Removed excess/empty auto-generated <xs:sequence/> 
- Added root entry-point elements to the schemas in the vmr folder (note vMR element is lower case for first letter)
- Corrected any file path errors for xs:include statements
- Alphabetized order of schema complex types
- Formatted XML using "Prettty Print" feature of Altova XMLSpy