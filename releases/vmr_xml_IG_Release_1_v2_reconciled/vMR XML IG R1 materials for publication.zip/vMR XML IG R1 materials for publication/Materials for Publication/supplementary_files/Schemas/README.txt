Note that these XML Schemas were auto-generated from the HL7 vMR Domain Analysis Model (DAM), Release 2.  The only manual updates following the auto-generation are as follows:
- Removed excess/empty auto-generated <xs:sequence/> 
- Added root entry-point elements to the schemas in the vmr folder