OneModel
========

vMR/QDM Harmonization