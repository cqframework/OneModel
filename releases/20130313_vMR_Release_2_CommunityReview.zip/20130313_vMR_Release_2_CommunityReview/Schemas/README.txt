Note that these informative XML Schemas were primarily auto-generated from the HL7 vMR Domain Analysis Model (DAM), Release 1.

These Schemas have been enhanced in several ways compared to the UML DAM.  These enhancements are expected to be incorporated into a future release of the vMR DAM.  See the comments at the top of vmr.xsd for details.